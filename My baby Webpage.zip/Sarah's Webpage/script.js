// Mobile menu
const btn = document.querySelector('.menu-btn');
const nav = document.getElementById('nav');
if (btn && nav) {
  btn.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    btn.setAttribute('aria-expanded', open);
  });
}
// Footer year
document.querySelectorAll('.yr').forEach(el => el.textContent = new Date().getFullYear());
// Quote form validation
const form = document.getElementById('quote');
if (form) {
  form.addEventListener('submit', e => {
    e.preventDefault();
    let ok = true;
    form.querySelectorAll('[required]').forEach(input => {
      const err = document.getElementById(input.id + '-err');
      const value = input.value.trim();
      const bad = !value || (input.type === 'email' && !/^\S+@\S+\.\S+$/.test(value));
      err.textContent = bad ? 'Please enter a valid ' + input.dataset.label + '.' : '';
      input.setAttribute('aria-invalid', bad);
      if (bad) ok = false;
    });
    const msg = document.getElementById('msg');
    msg.textContent = ok ? 'Thank you! Your request is ready. Add your email or messaging link in script.js to receive it.' : 'Please fix the errors above.';
    if (ok) form.reset();
  });
}